import React from 'react';
import { Disc, Play, Radio, Calendar, Mail, Instagram, Twitter } from 'lucide-react';

function App() {
  const artists = [
    {
      name: "Dark Matter",
      genre: "Electronic",
      image: "https://images.unsplash.com/photo-1571778410519-6e2b75c5b676?w=800&q=80",
    },
    {
      name: "Neon Pulse",
      genre: "Synthwave",
      image: "https://images.unsplash.com/photo-1598387846148-47e82ee120cc?w=800&q=80",
    },
    {
      name: "Steel Echo",
      genre: "Industrial",
      image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&q=80",
    }
  ];

  const releases = [
    {
      title: "Midnight Protocol",
      artist: "Dark Matter",
      date: "March 2024",
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80"
    },
    {
      title: "Neon Dreams",
      artist: "Neon Pulse",
      date: "February 2024",
      image: "https://images.unsplash.com/photo-1557672172-298e090bd0f1?w=800&q=80"
    },
    {
      title: "Industrial Revolution",
      artist: "Steel Echo",
      date: "January 2024",
      image: "https://images.unsplash.com/photo-1558584673-c834fb1cc4b1?w=800&q=80"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <header className="relative h-screen">
        <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent z-10" />
        <img 
          src="https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=1920&q=80" 
          alt="Hero" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20">
          <nav className="container mx-auto px-4 py-6 flex justify-between items-center">
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Disc className="text-red-600" /> GRITTX
            </h1>
            <div className="flex gap-8">
              <a href="#artists" className="hover:text-red-600 transition">Artists</a>
              <a href="#releases" className="hover:text-red-600 transition">Releases</a>
              <a href="#events" className="hover:text-red-600 transition">Events</a>
              <a href="#contact" className="hover:text-red-600 transition">Contact</a>
            </div>
          </nav>
          
          <div className="container mx-auto px-4 pt-32">
            <h2 className="text-7xl font-bold mb-6">PUSHING BOUNDARIES<br />IN SOUND</h2>
            <p className="text-xl text-gray-300 max-w-2xl mb-8">
              Independent record label championing the next generation of electronic music pioneers.
            </p>
            <button className="bg-red-600 px-8 py-3 rounded-full font-bold hover:bg-red-700 transition flex items-center gap-2">
              <Play size={20} /> Latest Releases
            </button>
          </div>
        </div>
      </header>

      {/* Artists Section */}
      <section id="artists" className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-12">
            <Radio className="text-red-600 w-8 h-8" />
            <h3 className="text-4xl font-bold">Our Artists</h3>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {artists.map((artist) => (
              <div key={artist.name} className="group relative overflow-hidden rounded-lg">
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent z-10 opacity-60 group-hover:opacity-80 transition" />
                <img 
                  src={artist.image} 
                  alt={artist.name}
                  className="w-full h-96 object-cover transform group-hover:scale-105 transition duration-500"
                />
                <div className="absolute bottom-0 left-0 right-0 p-6 z-20">
                  <h4 className="text-2xl font-bold mb-2">{artist.name}</h4>
                  <p className="text-red-600">{artist.genre}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Releases Section */}
      <section id="releases" className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-12">
            <Disc className="text-red-600 w-8 h-8" />
            <h3 className="text-4xl font-bold">Latest Releases</h3>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {releases.map((release) => (
              <div key={release.title} className="bg-zinc-900 rounded-lg overflow-hidden group">
                <div className="relative overflow-hidden">
                  <img 
                    src={release.image} 
                    alt={release.title}
                    className="w-full h-64 object-cover transform group-hover:scale-105 transition duration-500"
                  />
                  <button className="absolute inset-0 bg-red-600/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                    <Play className="w-12 h-12" />
                  </button>
                </div>
                <div className="p-6">
                  <h4 className="text-xl font-bold mb-2">{release.title}</h4>
                  <p className="text-gray-400 mb-2">{release.artist}</p>
                  <p className="text-red-600">{release.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section id="events" className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-12">
            <Calendar className="text-red-600 w-8 h-8" />
            <h3 className="text-4xl font-bold">Upcoming Events</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-black p-8 rounded-lg">
              <div className="text-red-600 text-xl mb-4">MAR 15</div>
              <h4 className="text-2xl font-bold mb-2">Label Night: Dark Matter Live</h4>
              <p className="text-gray-400 mb-4">Underground Club, New York</p>
              <button className="border-2 border-red-600 px-6 py-2 rounded-full hover:bg-red-600 transition">
                Get Tickets
              </button>
            </div>
            <div className="bg-black p-8 rounded-lg">
              <div className="text-red-600 text-xl mb-4">APR 02</div>
              <h4 className="text-2xl font-bold mb-2">Neon Pulse Album Launch</h4>
              <p className="text-gray-400 mb-4">Tech Hub, Berlin</p>
              <button className="border-2 border-red-600 px-6 py-2 rounded-full hover:bg-red-600 transition">
                Get Tickets
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-12">
            <Mail className="text-red-600 w-8 h-8" />
            <h3 className="text-4xl font-bold">Get in Touch</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-xl text-gray-300 mb-8">
                Looking to release your music or collaborate? We're always on the lookout for fresh talent.
              </p>
              <div className="flex gap-6">
                <a href="#" className="text-gray-400 hover:text-red-600 transition">
                  <Instagram size={24} />
                </a>
                <a href="#" className="text-gray-400 hover:text-red-600 transition">
                  <Twitter size={24} />
                </a>
              </div>
            </div>
            <form className="space-y-6">
              <input 
                type="text" 
                placeholder="Name" 
                className="w-full bg-zinc-900 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
              />
              <input 
                type="email" 
                placeholder="Email" 
                className="w-full bg-zinc-900 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
              />
              <textarea 
                placeholder="Message" 
                rows={4}
                className="w-full bg-zinc-900 p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
              />
              <button className="bg-red-600 px-8 py-3 rounded-full font-bold hover:bg-red-700 transition w-full">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-zinc-800">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>© 2024 Grittx Records. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;